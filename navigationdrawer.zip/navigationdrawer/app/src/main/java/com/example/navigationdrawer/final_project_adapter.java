package com.example.navigationdrawer;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class final_project_adapter extends RecyclerView.Adapter {

    ArrayList<books> bookNumber;
    Context context;



    public final_project_adapter(ArrayList<books>bookNumber, Context context) {
        this.bookNumber = bookNumber;
        this.context = context;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.activity_main3, parent, false);
        Viewholder vh = new Viewholder((v));
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        ((Viewholder) holder).ing.setImageResource(bookNumber.get(position).getImage());
        ((Viewholder) holder).price.setText(bookNumber.get(position).getPrice() + "");
        ((Viewholder) holder).name.setText(bookNumber.get(position).getBookName());
        ((Viewholder) holder).author.setText(bookNumber.get(position).getAuthor());
        ((Viewholder) holder).subject.setText(bookNumber.get(position).getCondition());


    }



    @Override
    public int getItemCount() { return bookNumber.size();
    }

    public static class Viewholder extends RecyclerView.ViewHolder {

        public ImageView ing;
        public TextView name;
        public TextView price;
        public TextView author;
        public TextView subject;
        public View view;

        public Viewholder(@NonNull View itemView) {
            super(itemView);
            view =itemView;
            ing = itemView.findViewById(R.id.imageView);
            name= itemView.findViewById(R.id.AUM_name);
            author = itemView.findViewById(R.id.textView2);
            price= itemView.findViewById(R.id.AUM_author);
            subject = itemView.findViewById(R.id.AUM_price);


        }
    }
}
