package com.example.navigationdrawer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);



        ArrayList<books> bookNumber = new ArrayList<>();

        books b1 = new books("biology101",R.drawable.ic_baseline_account_box_24,13,"yousef","good","biology");
        books b2 = new books("chemistry101",R.drawable.ic_baseline_account_box_24,13,"yousef","good","chemistry");
        books b3 = new books("english101",R.drawable.ic_baseline_account_box_24,13,"yousef","good","english");
        books b4 = new books("maths101",R.drawable.ic_baseline_account_box_24,13,"yousef","good","maths");
        books b5 = new books("physics101",R.drawable.ic_baseline_account_box_24,13,"yousef","good","physics");
        books b6 = new books("history101",R.drawable.ic_baseline_account_box_24,13,"yousef","good","history");
        books b7 = new books("geography101",R.drawable.ic_baseline_account_box_24,13,"yousef","good","geography");






        bookNumber.add(b1);
        bookNumber.add(b2);
        bookNumber.add(b3);
        bookNumber.add(b4);
        bookNumber.add(b5);
        bookNumber.add(b6);
        bookNumber.add(b7);

        RecyclerView RV =findViewById(R.id.AUM_RecyclerView);
        RV.setHasFixedSize(true);
        RecyclerView.LayoutManager im = new LinearLayoutManager(this);
        RV.setLayoutManager(im);

        AUM_adapter pa = new AUM_adapter(bookNumber,this);
        RV.setAdapter(pa);

    }
}