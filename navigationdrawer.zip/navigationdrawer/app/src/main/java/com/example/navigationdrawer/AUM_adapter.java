package com.example.navigationdrawer;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AUM_adapter extends RecyclerView.Adapter {

    public AUM_adapter(ArrayList<books> bookNumber2, Context context2) {
        this.bookNumber2 = bookNumber2;
        this.context2 = context2;
    }

    ArrayList<books> bookNumber2;
    Context context2;

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context2).inflate(R.layout.aum_item_list, parent, false);
        final_project_adapter.Viewholder vh = new final_project_adapter.Viewholder((v));
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((Viewholder) holder).ing.setImageResource(bookNumber2.get(position).getImage());
        ((Viewholder) holder).price.setText(bookNumber2.get(position).getPrice() + "");
        ((Viewholder) holder).name.setText(bookNumber2.get(position).getBookName());
        ((Viewholder) holder).author.setText(bookNumber2.get(position).getAuthor());
        ((Viewholder) holder).subject.setText(bookNumber2.get(position).getCondition());

    }

    @Override
    public int getItemCount() {
        return bookNumber2.size();


    }


    public static class Viewholder extends RecyclerView.ViewHolder {

        public ImageView ing;
        public TextView name;
        public TextView price;
        public TextView author;
        public TextView subject;
        public View view;

        public Viewholder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            ing = itemView.findViewById(R.id.AUM_imageView);
            name = itemView.findViewById(R.id.AUM_name);
            author = itemView.findViewById(R.id.AUM_author);
            price = itemView.findViewById(R.id.AUM_condition);
            subject = itemView.findViewById(R.id.AUM_price);


        }
    }
}


