package com.example.navigationdrawer;

import java.io.Serializable;

public class books implements Serializable {
    public books() {
    }

    public books(String bookName, int image, int price, String author, String condition, String subject) {
        this.bookName = bookName;
        this.image = image;
        this.price = price;
        this.author = author;
        this.condition = condition;
        this.subject = subject;
    }

    String bookName;
    int image;
    int price;
    String author;
    String condition;
    String subject;

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
